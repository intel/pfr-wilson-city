import os
import hashlib
import math
import string 
import random

"""
Important Note: Need to use Python Version 3.0 or newer 

The input to this script are various full chip PCH and BMC images for unit tests.
The outputs are the signed full chip images, the signed pfm images and the signed
update capsules

Important Note: This script assumes we are in the ship/fw/test/testdata directory

"""

class pfr_image(object):
    
    # Blocksign tool commands/paths
    make_blk_sign_cmd = "make -C ../../../bin/blocksign_tool/source"
    blk_sign_path = "../../../bin/blocksign_tool/source/blocksign -c ../../../bin/blocksign_tool/config_xmls/"
    page_size = 4096
    
    signature_size = 0x400
	
	# PFM offsets
    pfm_region_type_def = 0x0
    pfm_spi_region_start_addr_offset = 0x008
    pfm_spi_region_end_addr_offset = 0x00C
    pfm_spi_hash_offset = 0x010
    pfm_spi_hash_info_offset = 0x02
    pfm_spi_size_with_sha256 = 48
    pfm_spi_size_no_hash = 16
    pfm_smbus_size = 40
    pfm_size_addr_offset = 0x01C    
    spi_region = 0x1
    smbus_region = 0x2
    
    # Recovery/Staging/Compression Offsets
    comp_tag_off = 0x0
    comp_version_off = 0x04
    comp_page_size_off = 0x08
    comp_page_patt_off = 0x10
    comp_bmp_size_bits_off = 0x014	
    comp_pay_length_off = 0x018
    comp_active_bmp_off = 0x080

    def __init__(self, image, image_name, image_size):

        self.image = image
        self.image_name = image_name
        self.image_size = image_size
        self.num_pages = self.image_size / self.page_size
        self.page_bitmap_num_bytes = self.num_pages / 8	
                
        # pfm start and end addresses, default = 0	
        self.pfm_base = 0 
        self.pfm_end = 0
    
        # PFM addresses/offsets and info
        self.pfm_after_signature = self.pfm_base + self.signature_size
        self.pfm_body_base = self.pfm_after_signature + 0x020
        self.pfm_svn = self.pfm_after_signature + 0x04
        self.pfm_bkc = self.pfm_after_signature + 0x05		
        self.major_rev = self.pfm_after_signature + 0x06
        self.minor_rev = self.pfm_after_signature + 0x07

        # Recovery and staging 
        self.rec_base = 0
        self.rec_end = 0
        self.stage_base = 0
        self.stage_end = 0          	
        self.rec_pfm_addr = self.rec_base + self.signature_size		
        self.comp_compress_bmp_off = self.comp_active_bmp_off + self.page_bitmap_num_bytes
        self.comp_pay_off = self.comp_compress_bmp_off + self.page_bitmap_num_bytes
		
        #fw start and end addr lists
        self.fw_start_addr_list = []	
        self.fw_end_addr_list = []
	
    def set_pfm_region(self, pfm_base, pfm_end):
        self.pfm_base = pfm_base
        self.pfm_end = pfm_end
        self.pfm_after_signature = self.pfm_base + self.signature_size
        self.pfm_body_base = self.pfm_after_signature + 0x020
        self.pfm_svn = self.pfm_after_signature + 0x04
        self.pfm_bkc = self.pfm_after_signature + 0x05		
        self.major_rev = self.pfm_after_signature + 0x06
        self.minor_rev = self.pfm_after_signature + 0x07

    def set_recovery_region(self, rec_base, rec_end):
        self.rec_base = rec_base
        self.rec_end = rec_end
        self.rec_pfm_addr = self.rec_base + self.signature_size

    def set_staging_region(self, stage_base, stage_end):
        self.stage_base = stage_base
        self.stage_end = stage_end
		
    def add_fw_region(self, start_addr, end_addr):
        self.fw_start_addr_list.append(start_addr)
        self.fw_end_addr_list.append(end_addr)		
	
    def fill_all_fw_region(self, empty_to_full_ratio):
        for i in range(len(self.fw_start_addr_list)):
            self.fill_fw_region(self.fw_start_addr_list[i], self.fw_end_addr_list[i], empty_to_full_ratio)
			
    """ Fill the desired fw region within the binary image. 
    Some fraction of pages' bytes will be set with one random value ranging from 0 to 254.
    The rest will be all 0xff (empty) so that the image can be compressed. The percentage
    of empty data depends on empty_to_full ratio, which needs to be between
    0 and 1 """
    def fill_fw_region(self, start_addr, end_addr, empty_to_full_ratio):
    
        fw_size = end_addr - start_addr
        num_pages = fw_size//self.page_size
        num_empty_pages_required = math.floor(empty_to_full_ratio*(num_pages))
        int_byte_data = 0
    
        set_all_ones = True
        num_empty_pages = 0
        num_pages_filled = 0
        self.image.seek(start_addr)
        for i in range (0, fw_size, self.page_size):        
            """randomize which pages will be empty,
            but make sure empty_to_full_ratio is met"""
            set_all_ones = ((random.randint(1,10)) <= 5)           
            num_pages_left = num_pages - num_pages_filled
            num_empty_to_fill = num_empty_pages_required - num_empty_pages			
            if ((num_pages_left) <= num_empty_to_fill):
                set_all_ones = True
            
            """don't let the first page be empty because
            the current unit tests erase the first page.
            this will need to be changed""" 			
            if (i == 0 or num_empty_to_fill == 0): 
                set_all_ones = False
            	        
            if (set_all_ones == True):
                byte_data = bytes([0xff])
                page_data = byte_data * self.page_size
                self.image.write(page_data)
                num_empty_pages += 1
                num_pages_filled += 1				
            else:
                int_byte_data = random.randint(0, 254)
                byte_data = bytes([int_byte_data])            
                page_data = byte_data * self.page_size
                self.image.write(page_data)            
                num_pages_filled += 1	                    		
        return
    
    def update_all_fw_spi_hash(self):
        for i in range(len(self.fw_start_addr_list)):
            self.update_fw_spi_hash(self.fw_start_addr_list[i], self.fw_end_addr_list[i])                   	
    
    # update the hash in the fw spi region 
    def update_fw_spi_hash(self, fw_start_addr, fw_end_addr):
        fw_size = fw_end_addr - fw_start_addr
    	
	    # check if using sha256 (only need to check for sha256 because the other hashes haven't been set yet)
        pfm_spi_location = self.get_spiaddr_in_pfm_body(fw_start_addr, fw_end_addr)
        hash_info_unmasked = self.read_word_from_binary_image(pfm_spi_location + self.pfm_spi_hash_info_offset, "little")
        if ((hash_info_unmasked & 0x1) == 0): 
            return

        hash = hashlib.sha256()
        new_hash = self.create_new_hash(hash, fw_start_addr, fw_size)
        self.image.seek(pfm_spi_location + self.pfm_spi_hash_offset)
        self.image.write(new_hash)
	
        return		

    # go through pfm body and look for the location where the new hash needs to be placed
    def get_spiaddr_in_pfm_body(self, start_addr_search, end_addr_search):
        found_spiregion = 0
        reach_body_end = 0
        pfm_ptr = self.pfm_body_base
        while (found_spiregion == 0 and reach_body_end == 0):
            self.image.seek(pfm_ptr)
            region_type = int.from_bytes(self.image.read(1),"little")                
        
            if (region_type == self.spi_region):
                start_addr = self.get_pfm_spi_region_start_addr(pfm_ptr)
                end_addr = self.get_pfm_spi_region_end_addr(pfm_ptr)
                if (start_addr == start_addr_search and end_addr == end_addr_search):
                    found_spiregion = 1               
                    return pfm_ptr
                else:
                    hash_info_unmasked = self.read_word_from_binary_image(pfm_ptr + self.pfm_spi_hash_info_offset, "little")
                    if ((hash_info_unmasked & 0x1) == 0): 			
                        pfm_ptr += self.pfm_spi_size_no_hash
                    else:
                        pfm_ptr += self.pfm_spi_size_with_sha256			
        
            elif (region_type == self.smbus_region):
                pfm_ptr += self.pfm_smbus_size

            else:
                reach_body_end = 1
                print("reached end of body @ address: ")
                print(hex(pfm_ptr))
                print("spi start address search: ")
                print(hex(start_addr_search))				
                print("spi end address search: ")
                print(hex(end_addr_search))
                assert(reach_body_end == 0), "reached end of pfm body, please provide valid region"

        return pfm_ptr 

    """
    read out set of bytes from bin file
    and return an int based on preferred byte
    order (i.e. big vs little endian)
    """
    def read_word_from_binary_image(self, addr, byteorder):
        self.image.seek(addr)
        val_bytes = self.image.read(4)
        val = int.from_bytes(val_bytes, byteorder)
        return val		
        		
    def create_new_hash(self, hash_obj, addr, num_bytes):
        self.image.seek(addr)
        region_data = self.image.read(num_bytes)
        hash_obj.update(region_data)
        new_hash = hash_obj.digest()
        return new_hash				

    def get_pfm_spi_region_start_addr(self, pfm_spi_region_base):
        spi_start_addr = self.read_word_from_binary_image(pfm_spi_region_base + self.pfm_spi_region_start_addr_offset, "little")
        return spi_start_addr

    def get_pfm_spi_region_end_addr(self, pfm_spi_region_base):
        spi_end_addr = self.read_word_from_binary_image(pfm_spi_region_base + self.pfm_spi_region_end_addr_offset, "little")
        return spi_end_addr
		
    def blocksign_pfm(self, config_xml_file, pfm_signed_name):
        pfm_size = self.get_pfm_size()
        self.blocksign(self.pfm_after_signature, pfm_size, self.pfm_base, config_xml_file, pfm_signed_name)    

    def get_pfm_size(self):
        pfm_size = self.read_word_from_binary_image(self.pfm_after_signature + self.pfm_size_addr_offset, "little")
        return pfm_size

    def blocksign(self, data_to_sign_addr, data_to_sign_size, signature_addr, config_xml_file, signed_image_name):	
        self.image.seek(data_to_sign_addr)
        data_to_sign = self.image.read(int(data_to_sign_size))
        unsign_image_name = "tmp.bin"
        unsign_image_bin = open(unsign_image_name, "w+b")
        unsign_image_bin.seek(0)
        unsign_image_bin.write(data_to_sign)
        unsign_image_bin.close()

        # perform blocksign and copy into signature region
        os.system(self.make_blk_sign_cmd)
        block_sign_cmd = self.blk_sign_path + config_xml_file + " -o " + signed_image_name + " " + unsign_image_name
        os.system(block_sign_cmd)
        sign_image = open(signed_image_name, "r+b")
        sign_image.seek(0)
        new_sig = sign_image.read(self.signature_size)
        self.image.seek(signature_addr)
        self.image.write(new_sig)
        sign_image.close()
    
    def in_pfr_region(self, img_addr):
        in_pfm_region = (img_addr >= self.pfm_base and img_addr < self.pfm_end) 
        in_recovery_region = (img_addr >= self.rec_base and img_addr < self.rec_end) 
        in_staging_region = (img_addr >= self.stage_base and img_addr < self.stage_end)
        return (in_pfm_region or in_recovery_region or in_staging_region)
    
    def set_major_version_in_pfm(self, value):
        self.image.seek(self.major_rev)
        self.image.write(bytes([value]))
	
    def set_minor_version_in_pfm(self, value):
        self.image.seek(self.minor_rev)
        self.image.write(bytes([value]))	
	
    def set_svn_in_pfm(self, value):
        self.image.seek(self.pfm_svn)
        self.image.write(bytes([value]))

    def set_bkc_in_pfm(self, value):		
        self.image.seek(self.pfm_bkc)
        self.image.write(bytes([value]))

    def create_recovery_capsule(self, capsule_config_xml, capsule_file_name):
    
        # copy the PFM into the PFM Region of the Recovery Capsule
        pfm_size = self.get_pfm_size()
        self.image.seek(self.pfm_base)
        pfm_data = self.image.read(self.signature_size + pfm_size)
        self.image.seek(self.rec_pfm_addr)
        self.image.write(pfm_data)
	
        """ iterate through the entire image and create the bitmaps and payload
        active bit map will be set to erase pages not located in pfm, recovery or staging regions
        compression bitmap will only compress pages not in pfm, recovery or staging regions"""
        active_bmp = bytearray(int(self.page_bitmap_num_bytes))
        compress_bmp = bytearray(int(self.page_bitmap_num_bytes))
        page_patt = b'\xff' * self.page_size	
        payload_num_pgs = 0
        page = 0
        comp_struct_base = self.rec_base + 2*self.signature_size + pfm_size
        comp_pay_ptr = comp_struct_base + self.comp_pay_off 
        for img_addr in range (0, self.image_size, self.page_size):
            if (not(self.in_pfr_region(img_addr))):
                self.image.seek(int(img_addr))
                active_bmp[page >> 3] |= 1 << (7- (page % 8)) #Big Endian bit map
                page_data = self.image.read(self.page_size)			
                if (page_data != page_patt):    		
                    compress_bmp[page >> 3] |= 1 << (7- (page % 8)) #Big Endian bit map
                    payload_num_pgs += 1
                    self.image.seek(int(comp_pay_ptr))
                    self.image.write(page_data)
                    comp_pay_ptr += self.page_size				
        
            page += 1
    
        # update compression structure information
        pay_size = payload_num_pgs * self.page_size
        pay_size_bytes = pay_size.to_bytes(4, 'little')    
        act_bmp_bytes = bytes(active_bmp)
        comp_bmp_bytes = bytes(compress_bmp)             			
        self.image.seek(int(comp_struct_base + self.comp_active_bmp_off))
        self.image.write(act_bmp_bytes)
        self.image.seek(int(comp_struct_base + self.comp_compress_bmp_off))
        self.image.write(comp_bmp_bytes)
        self.image.seek(int(comp_struct_base + self.comp_pay_length_off))
        self.image.write(pay_size_bytes)
    
	    # update the capsule signature
        data_to_sign_size = (comp_pay_ptr) - (self.rec_base + self.signature_size)
        self.blocksign(self.rec_base + self.signature_size, data_to_sign_size, self.rec_base, capsule_config_xml, capsule_file_name)	

    def get_comp_struct_base(self):	
        return (self.rec_base + 2*self.signature_size + self.get_pfm_size())

    def get_payload_length(self):
        comp_struct_base = self.get_comp_struct_base()
        return (self.read_word_from_binary_image(comp_struct_base + self.comp_pay_length_off, "little"))
	
    def set_compression_struct_tag(self, value):
        comp_struct_base = self.get_comp_struct_base()
        self.image.seek(comp_struct_base + self.comp_tag_off)
        self.image.write(value.to_bytes(4, 'little'))		
    
    def set_compression_struct_version(self, value):
        comp_struct_base = self.get_comp_struct_base()
        self.image.seek(comp_struct_base + self.comp_version_off)
        self.image.write(value.to_bytes(4, 'little'))
    
    def set_compression_page_size(self, value):
        comp_struct_base = self.get_comp_struct_base()
        self.image.seek(comp_struct_base + self.comp_page_size_off)
        self.image.write(value.to_bytes(4, 'little'))	

    def set_compression_page_pattern(self, value):
        comp_struct_base = self.get_comp_struct_base()
        self.image.seek(comp_struct_base + self.comp_page_patt_off)
        self.image.write(value.to_bytes(4, 'little'))	

    def set_compression_struct_nbits_bitmap(self, value):
        comp_struct_base = self.get_comp_struct_base()
        self.image.seek(comp_struct_base + self.comp_bmp_size_bits_off)
        self.image.write(value.to_bytes(4, 'little'))
    
    def get_comp_struct_size(self):	
        comp_struct_base = self.get_comp_struct_base()
        payload_size = self.get_payload_length()
        pfm_size_total = self.get_pfm_size() + self.signature_size		
        comp_struct_size = self.comp_active_bmp_off + 2*self.page_bitmap_num_bytes + payload_size + pfm_size_total
        return comp_struct_size		

def main():
    
    # BMC ADDRESSES/info
    bmc_pfm_base = 0x80000
    bmc_pfm_end = 0xa0000
    bmc_rec_base = 0x2a00000
    bmc_rec_end = 0x4a00000
    bmc_stage_base = 0x4a00000
    bmc_stage_end = 0x8000000    
    bmc_fw_start_addrs = [
        0x0,
        0xa0000,
        0xc0000,
        0x2c0000,
        0xb00000
    ]    
    bmc_fw_end_addrs = [
        0x80000,
        0xc0000,
        0x2c0000,
        0xb00000,
        0x2a00000
    ]
    bmc_img_size = 0x8000000

    # PCH ADDRESSES/info
    pch_stage_base = 0x7f0000
    pch_stage_end = 0x1bf0000	
    pch_rec_base = 0x1bf0000
    pch_rec_end = 0x2ff0000
    pch_pfm_base = 0x2ff0000
    pch_pfm_end = 0x3000000
    pch_fw_start_addrs = [
        0x0,
        0x1000,
        0x3000,
        0x28000,
        0xbf000,
        0x7b8000,
        0x7c8000,
        0x7e0000,
        0x03000000,
        0x03240000
    ]
    pch_fw_end_addrs = [
        0x1000,
        0x3000,
        0x28000,
        0xbf000,
        0x7b8000,
        0x7c8000,
        0x7e0000,
        0x7f0000,
        0x03240000,
        0x04000000
    ]
    pch_img_size = 0x4000000
    
    ################## Modify the original Full Chip PCH and BMC images #################	
    # Modify BMC image 
    bmc_image_filename = "full_pfr_image_bmc.bin"
    bmc_file = open(bmc_image_filename, "r+b")  	
    bmc_image = pfr_image(bmc_file, bmc_image_filename, bmc_img_size)
    bmc_image.set_pfm_region(bmc_pfm_base, bmc_pfm_end)
    bmc_image.set_recovery_region(bmc_rec_base, bmc_rec_end)
    bmc_image.set_staging_region(bmc_stage_base, bmc_stage_end)
    
    for i in range(len(bmc_fw_start_addrs)):
        bmc_image.add_fw_region(bmc_fw_start_addrs[i], bmc_fw_end_addrs[i])
    	
    bmc_image.fill_all_fw_region(0.5)
    bmc_image.update_all_fw_spi_hash()	    
    bmc_image.blocksign_pfm("bmc_pfm.xml", "signed_pfm_bmc.bin")    
    bmc_image.create_recovery_capsule("bmc_update_capsule.xml", "signed_capsule_bmc.bin")
    bmc_file.close()

    # Modify PCH image	
    pch_image_filename = "full_pfr_image_pch.bin"
    pch_file = open(pch_image_filename, "r+b")  	
    pch_image = pfr_image(pch_file, pch_image_filename, pch_img_size)
    pch_image.set_pfm_region(pch_pfm_base, pch_pfm_end)
    pch_image.set_recovery_region(pch_rec_base, pch_rec_end)
    pch_image.set_staging_region(pch_stage_base, pch_stage_end)
    
    for i in range(len(pch_fw_start_addrs)):
        pch_image.add_fw_region(pch_fw_start_addrs[i], pch_fw_end_addrs[i])

    pch_image.fill_all_fw_region(0.5)
    pch_image.update_all_fw_spi_hash()	    
    
    pch_image.blocksign_pfm("pch_pfm.xml", "signed_pfm_pch.bin")    
    pch_image.create_recovery_capsule("pch_update_capsule.xml", "signed_capsule_pch.bin")
    pch_file.close()

    #####################################################################################

    ################## Modify the Anti Rollback testing capsules ########################
    anti_rollback_svn_dir = "anti_rollback_with_svn/"
	
    # PCH recovery capsule with csk id 10 changed
    pch_image_name_with_csk_id_10 = "anti_rollback_with_csk_id/full_pfr_pch_with_with_recovery_csk_id_10.bin" 
    os.system("cp -rL " + pch_image_filename + " " + pch_image_name_with_csk_id_10)
    pch_csk_10_file = open(pch_image_name_with_csk_id_10, "r+b")  	
    pch_csk_10_img = pfr_image(pch_csk_10_file, pch_image_filename, pch_img_size)
    pch_csk_10_img.set_pfm_region(pch_pfm_base, pch_pfm_end)
    pch_csk_10_img.set_recovery_region(pch_rec_base, pch_rec_end)
    pch_csk_10_img.set_staging_region(pch_stage_base, pch_stage_end)
    
    for i in range(len(pch_fw_start_addrs)):
        pch_csk_10_img.add_fw_region(pch_fw_start_addrs[i], pch_fw_end_addrs[i])
        
    pch_csk_10_img.blocksign_pfm("pch_pfm.xml", "signed_pfm_pch.bin")    
    pch_csk_10_img.create_recovery_capsule("pch_update_capsule_with_csk_id10.xml", "anti_rollback_with_csk_id/signed_capsule_pch_with_csk_id10.bin")
    pch_csk_10_file.close()
   	
    # PCH antirollback capsule images with different SVN's changed 
    pch_anti_rollback_svn_img = []
    pch_anti_rollback_capsule_names = [
        "signed_capsule_pch_pfm_with_svn64.bin",
        "signed_capsule_pch_pfm_with_svn7.bin",
        "signed_capsule_pch_pfm_with_svn9.bin"
    ]
    pch_anti_rollback_svn_values = [64, 7, 9]
	
    for i in range(len(pch_anti_rollback_svn_values)):
        capsule_final_name = anti_rollback_svn_dir + pch_anti_rollback_capsule_names[i]
        full_img_svn_rollback_name = anti_rollback_svn_dir + "full_pch_with_" + pch_anti_rollback_capsule_names[i]	
        os.system("cp -rL " + pch_image_filename + " " + full_img_svn_rollback_name)
        full_img_svn_file = open(full_img_svn_rollback_name, "r+b")
        pch_anti_rollback_svn_img.append(pfr_image(full_img_svn_file, full_img_svn_rollback_name, pch_img_size))
        pch_anti_rollback_svn_img[i].set_pfm_region(pch_pfm_base, pch_pfm_end)
        pch_anti_rollback_svn_img[i].set_recovery_region(pch_rec_base, pch_rec_end)
        pch_anti_rollback_svn_img[i].set_staging_region(pch_stage_base, pch_stage_end)
        
        for j in range(len(pch_fw_start_addrs)):
            pch_anti_rollback_svn_img[i].add_fw_region(pch_fw_start_addrs[j], pch_fw_end_addrs[j])
                
        pch_anti_rollback_svn_img[i].set_svn_in_pfm(pch_anti_rollback_svn_values[i])
        pch_anti_rollback_svn_img[i].blocksign_pfm("pch_pfm.xml", "tmp_signed_pfm.bin")    
        pch_anti_rollback_svn_img[i].create_recovery_capsule("pch_update_capsule.xml",  capsule_final_name)
        full_img_svn_file.close()

    #BMC antirollback capsule with SVN 2 changed 
    bmc_anti_rollback_capsule_img = "signed_capsule_bmc_with_svn2.bin"
    bmc_anti_rollback_svn_value = 2
    capsule_final_name = anti_rollback_svn_dir + bmc_anti_rollback_capsule_img
    full_img_svn_rollback_name = anti_rollback_svn_dir + "full_pch_with_" + bmc_anti_rollback_capsule_img	
    os.system("cp -rL " + bmc_image_filename + " " + full_img_svn_rollback_name)
    full_img_svn_file = open(full_img_svn_rollback_name, "r+b")
    bmc_anti_rollback_svn_img = pfr_image(full_img_svn_file, full_img_svn_rollback_name, bmc_img_size)
    bmc_anti_rollback_svn_img.set_pfm_region(bmc_pfm_base, bmc_pfm_end)
    bmc_anti_rollback_svn_img.set_recovery_region(bmc_rec_base, bmc_rec_end)
    bmc_anti_rollback_svn_img.set_staging_region(bmc_stage_base, bmc_stage_end)
       
    for j in range(len(bmc_fw_start_addrs)):
        bmc_anti_rollback_svn_img.add_fw_region(bmc_fw_start_addrs[j], bmc_fw_end_addrs[j])
                
    bmc_anti_rollback_svn_img.set_svn_in_pfm(bmc_anti_rollback_svn_value)
    bmc_anti_rollback_svn_img.blocksign_pfm("bmc_pfm.xml", "tmp_signed_pfm.bin")    
    bmc_anti_rollback_svn_img.create_recovery_capsule("bmc_update_capsule.xml",  capsule_final_name)
    full_img_svn_file.close()   

    #####################################################################################

    ################## Modify the bad firmware capsules #################################
    bad_capsule_dir = "bad_firmware_capsule/"
	
    bad_fw_capsule_names = [
        "signed_capsule_pch_pfm_with_svn_0xFF.bin",
        "signed_capsule_pch_pfm_with_svn65.bin",
        "signed_capsule_pch_with_bad_bitmap_nbit_in_pbc_header.bin",
        "signed_capsule_pch_with_bad_page_size_in_pbc_header.bin",
        "signed_capsule_pch_with_bad_pattern_in_pbc_header.bin",
        "signed_capsule_pch_with_bad_tag_in_pbc_header.bin",
        "signed_capsule_pch_with_bad_version_in_pbc_header.bin",
        "signed_capsule_pch_with_pc_type_10.bin",
        "signed_capsule_pch_with_wrong_csk_permission.bin"
    ]

    bad_capsule_svns = [0xff, 65]

    bad_fw_capsule_imgs = []
    full_bad_img_files = []
    bad_capsule_final_names = []	
    for i in range(len(bad_fw_capsule_names)):
        full_bad_img_name = bad_capsule_dir + "full_bad_pch_with_" + bad_fw_capsule_names[i] 	
        os.system("cp -rL " + pch_image_filename + " " + full_bad_img_name)	
        full_bad_img_files.append(open(full_bad_img_name, "r+b"))
        bad_fw_capsule_imgs.append(pfr_image(full_bad_img_files[i], full_bad_img_name, pch_img_size))
        bad_fw_capsule_imgs[i].set_pfm_region(pch_pfm_base, pch_pfm_end)
        bad_fw_capsule_imgs[i].set_recovery_region(pch_rec_base, pch_rec_end)
        bad_fw_capsule_imgs[i].set_staging_region(pch_stage_base, pch_stage_end)
        
        for j in range(len(pch_fw_start_addrs)):
            bad_fw_capsule_imgs[i].add_fw_region(pch_fw_start_addrs[j], pch_fw_end_addrs[j])		
        bad_capsule_final_names.append(bad_capsule_dir + bad_fw_capsule_names[i])
    
    # Set up the bad svn capsules
    for i in range(len(bad_capsule_svns)):
        bad_fw_capsule_imgs[i].set_svn_in_pfm(bad_capsule_svns[i])
        bad_fw_capsule_imgs[i].blocksign_pfm("pch_pfm.xml", "tmp_signed_pfm.bin")    
        bad_fw_capsule_imgs[i].create_recovery_capsule("pch_update_capsule.xml",  bad_capsule_final_names[i])
        full_bad_img_files[i].close()
    
    # Set up the capsule containing the wrong number of bitmap bits information
    pch_capsule_size = bad_fw_capsule_imgs[2].get_comp_struct_size()
    pch_capsule_after_signature_off = bad_fw_capsule_imgs[2].rec_base + bad_fw_capsule_imgs[2].signature_size
    bad_fw_capsule_imgs[2].set_compression_struct_nbits_bitmap(0xdb)    
    bad_fw_capsule_imgs[2].blocksign(pch_capsule_after_signature_off, pch_capsule_size, pch_rec_base, "pch_update_capsule.xml", bad_capsule_final_names[2])
    full_bad_img_files[2].close()	
    
    # Set up the capsule containing the wrong page size number information
    bad_fw_capsule_imgs[3].set_compression_page_size(0x4000)    
    bad_fw_capsule_imgs[3].blocksign(pch_capsule_after_signature_off, pch_capsule_size, pch_rec_base, "pch_update_capsule.xml", bad_capsule_final_names[3])
    full_bad_img_files[3].close()
    
    # Set up the capsule containg incorrect pattern for page compression
    bad_fw_capsule_imgs[4].set_compression_page_pattern(0x00)    
    bad_fw_capsule_imgs[4].blocksign(pch_capsule_after_signature_off, pch_capsule_size, pch_rec_base, "pch_update_capsule.xml", bad_capsule_final_names[4])
    full_bad_img_files[4].close()

    # Set up the capsule containg the incorrect magic number tag
    bad_fw_capsule_imgs[5].set_compression_struct_tag(0xDEADBEEF)    
    bad_fw_capsule_imgs[5].blocksign(pch_capsule_after_signature_off, pch_capsule_size, pch_rec_base, "pch_update_capsule.xml", bad_capsule_final_names[5])
    full_bad_img_files[5].close()

    # Set up the capsule containing the incorrect version in the pbc header
    bad_fw_capsule_imgs[6].set_compression_struct_version(0x01)    
    bad_fw_capsule_imgs[6].blocksign(pch_capsule_after_signature_off, pch_capsule_size, pch_rec_base, "pch_update_capsule.xml", bad_capsule_final_names[6])
    full_bad_img_files[6].close()

    # Set up the capsule containing the wrong pc type setting
    bad_fw_capsule_imgs[7].blocksign(pch_capsule_after_signature_off, pch_capsule_size, pch_rec_base, "pch_update_capsule_with_pc_type_10.xml", bad_capsule_final_names[7])
    full_bad_img_files[7].close()

    # Set up the capsule containing the wrong code signing key permission
    bad_fw_capsule_imgs[8].blocksign(pch_capsule_after_signature_off, pch_capsule_size, pch_rec_base, "pch_update_capsule_with_wrong_csk_permission.xml", bad_capsule_final_names[8])
    full_bad_img_files[8].close()

    #####################################################################################

    ################## Modify the BKC ID check PCH firmware capsule #####################
    bkc_id_check_dir = "bkc_id_check/"
    pch_bkc_chk_capsule_name = "signed_capsule_pch_pfm_with_bkc_ver2.bin"
	
    capsule_final_name = bkc_id_check_dir + pch_bkc_chk_capsule_name
    full_img_pch_bkc_chk_name = bkc_id_check_dir + "full_pch_with_" + pch_bkc_chk_capsule_name	
    os.system("cp -rL " + pch_image_filename + " " + full_img_pch_bkc_chk_name)
    full_img_pch_bkc_chk_file = open(full_img_pch_bkc_chk_name, "r+b")
    pch_pfm_bkc_id2_img = pfr_image(full_img_pch_bkc_chk_file, full_img_pch_bkc_chk_name, pch_img_size)
    pch_pfm_bkc_id2_img.set_pfm_region(pch_pfm_base, pch_pfm_end)
    pch_pfm_bkc_id2_img.set_recovery_region(pch_rec_base, pch_rec_end)
    pch_pfm_bkc_id2_img.set_staging_region(pch_stage_base, pch_stage_end)
        
    for i in range(len(pch_fw_start_addrs)):
        pch_pfm_bkc_id2_img.add_fw_region(pch_fw_start_addrs[i], pch_fw_end_addrs[i])

    pch_pfm_bkc_id2_img.set_bkc_in_pfm(0x02)
    pch_pfm_bkc_id2_img.blocksign_pfm("pch_pfm.xml", "tmp_signed_pfm.bin")    
    pch_pfm_bkc_id2_img.create_recovery_capsule("pch_update_capsule.xml",  capsule_final_name)
    full_img_pch_bkc_chk_file.close()
    #####################################################################################

    ################## Modify the full PCH image from hsd case 1507855229 ###############
    pch_hsd_fw_start_addrs = [
        0x0,
        0x1000,
        0x3000,
        0x28000,
        0xbf000,
        0x7b8000,
        0x7c8000,
        0x7e0000,
        0x03000000,
        0x037F0000,
		0x3800000,
		0x3850000,
		0x3880000,
		0x3900000
    ]
    pch_hsd_fw_end_addrs = [
        0x1000,
        0x3000,
        0x28000,
        0xbf000,
        0x7b8000,
        0x7c8000,
        0x7e0000,
        0x7f0000,
        0x37F0000,
        0x3800000,
		0x3850000,
		0x3880000,
		0x3900000,
		0x04000000
    ]

    pch_hsd_case_filename = "pch_firmware_recovery/full_pfr_image_pch_from_case_1507855229.bin"
    pch_hsd_case_file = open(pch_hsd_case_filename, "r+b")  	
    pch_hsd_image = pfr_image(pch_hsd_case_file, pch_hsd_case_filename, pch_img_size)
    pch_hsd_image.set_pfm_region(pch_pfm_base, pch_pfm_end)
    pch_hsd_image.set_recovery_region(pch_rec_base, pch_rec_end)
    pch_hsd_image.set_staging_region(pch_stage_base, pch_stage_end)
    
    for i in range(len(pch_fw_start_addrs)):
        pch_hsd_image.add_fw_region(pch_hsd_fw_start_addrs[i], pch_hsd_fw_end_addrs[i])

    pch_hsd_image.fill_all_fw_region(0.5)
    pch_hsd_image.update_all_fw_spi_hash()	    
    
    pch_hsd_image.blocksign_pfm("pch_pfm.xml", "tmp_hsd.bin")    
    pch_hsd_image.create_recovery_capsule("pch_update_capsule.xml", "tmp_hsd.bin")
    pch_hsd_case_file.close()

    #####################################################################################

    ################## Modify the PCH and BMC firmware update capsules ##################
    
    # BMC update images
    bmc_fw_update_filename = "bmc_firmware_update/full_pfr_image_bmc.bin"
    bmc_update_file = open(bmc_fw_update_filename, "r+b")  	
    bmc_update_image = pfr_image(bmc_update_file, bmc_fw_update_filename, bmc_img_size)
    bmc_update_image.set_pfm_region(bmc_pfm_base, bmc_pfm_end)
    bmc_update_image.set_recovery_region(bmc_rec_base, bmc_rec_end)
    bmc_update_image.set_staging_region(bmc_stage_base, bmc_stage_end)
    
    for i in range(len(bmc_fw_start_addrs)):
        bmc_update_image.add_fw_region(bmc_fw_start_addrs[i], bmc_fw_end_addrs[i])
    	
    bmc_update_image.fill_all_fw_region(0.6)
    bmc_update_image.update_all_fw_spi_hash()	    
    bmc_update_image.blocksign_pfm("bmc_pfm.xml", "bmc_firmware_update/signed_pfm_bmc.bin")    
    bmc_update_image.create_recovery_capsule("bmc_update_capsule.xml", "bmc_firmware_update/signed_capsule_bmc.bin")
    bmc_update_file.close()
	
    # PCH update images
    pch_fw_update_filename = "pch_firmware_update/full_pfr_image_pch.bin"
    pch_update_file = open(pch_fw_update_filename, "r+b")  	
    pch_fw_update_image = pfr_image(pch_update_file, pch_fw_update_filename, pch_img_size)
    pch_fw_update_image.set_pfm_region(pch_pfm_base, pch_pfm_end)
    pch_fw_update_image.set_recovery_region(pch_rec_base, pch_rec_end)
    pch_fw_update_image.set_staging_region(pch_stage_base, pch_stage_end)
    
    for i in range(len(pch_fw_start_addrs)):
        pch_fw_update_image.add_fw_region(pch_fw_start_addrs[i], pch_fw_end_addrs[i])

    pch_fw_update_image.fill_all_fw_region(0.4)
    pch_fw_update_image.update_all_fw_spi_hash()	    
    pch_fw_update_image.set_major_version_in_pfm(3)
    pch_fw_update_image.set_minor_version_in_pfm(12)
    pch_fw_update_image.blocksign_pfm("pch_pfm.xml", "pch_firmware_update/signed_pfm_pch.bin")    
    pch_fw_update_image.create_recovery_capsule("pch_update_capsule.xml", "pch_firmware_update/signed_capsule_pch.bin")
    pch_update_file.close()

    #####################################################################################

if __name__ == "__main__":
    main()
