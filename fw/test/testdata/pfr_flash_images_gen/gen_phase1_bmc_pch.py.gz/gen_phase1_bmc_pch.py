import os
import hashlib
import math
import string 
import random
import xml.etree.ElementTree as ET
import pfr_flash_image

""" This generates a phase one version of bmc and pch images for unit tests.
The images include a full image, recovery/update capsules and a pfm capsule."""

def main():

    """ Change these parameters to generate different images
    with different settings """
    bmc_img_name = "full_pfr_image_bmc_test.bin"
    bmc_pfm_img_name = "signed_pfm_bmc_test.bin"
    bmc_capsule_img_name = "signed_capsule_bmc_test.bin"
    bmc_empty_to_full_ratio = 0.55
    bmc_pfm_csk_id = 1
    bmc_rec_csk_id = 1
    bmc_svn = 0x1
    bmc_bkc = 0x1
    bmc_major_rev = 0
    bmc_minor_rev = 0x11
    bmc_use_sha256_blocksign = True
    bmc_use_sha384_blocksign = False
    pch_img_name = "full_pfr_image_pch_test.bin"
    pch_pfm_img_name = "signed_pfm_pch_test.bin"
    pch_capsule_img_name = "signed_capsule_pch_test.bin"
    pch_empty_to_full_ratio = 0.55
    pch_pfm_csk_id = 0
    pch_rec_csk_id = 0
    pch_svn = 0
    pch_bkc = 0
    pch_major_rev = 0
    pch_minor_rev = 0
    pch_use_sha256_blocksign = True
    pch_use_sha384_blocksign = False


    # BMC ADDRESSES/info    
    bmc_pfm_base = 0x80000
    bmc_pfm_end = 0xa0000
    bmc_rec_base = 0x2a00000
    bmc_rec_end = 0x4a00000
    bmc_stage_base = 0x4a00000
    bmc_stage_end = 0x8000000    

    """ These addresses need to cover all
    bmc spi regions (including pfm, rec, staging)"""    
    bmc_fw_start_addrs = [
        0x0,
        0x80000,
        0xa0000,
        0xc0000,
        0x2c0000,
        0xb00000,
        0x2a00000,
        0x4a00000
    ]    
    bmc_fw_end_addrs = [
        0x80000,
        0xa0000,
        0xc0000,
        0x2c0000,
        0xb00000,
        0x2a00000,
        0x4a00000,
        0x8000000
    ]
    bmc_img_size = 0x8000000

    # PCH ADDRESSES/info
    pch_stage_base = 0x7f0000
    pch_stage_end = 0x1bf0000	
    pch_rec_base = 0x1bf0000
    pch_rec_end = 0x2ff0000
    pch_pfm_base = 0x2ff0000
    pch_pfm_end = 0x3000000

    """ These addresses need to cover all
    pch spi regions (including pfm, rec, staging)""" 
    pch_fw_start_addrs = [
        0x0,
        0x1000,
        0x3000,
        0x28000,
        0xbf000,
        0x7b8000,
        0x7c8000,
        0x7e0000,
        0x7f0000,
        0x03000000,
        0x03240000
    ]
    pch_fw_end_addrs = [
        0x1000,
        0x3000,
        0x28000,
        0xbf000,
        0x7b8000,
        0x7c8000,
        0x7e0000,
        0x7f0000,
        0x03000000,
        0x03240000,
        0x04000000
    ]
    pch_img_size = 0x4000000

    ####################################### Create BMC Image ################################################

    bmc_image = pfr_flash_image.pfr_flash_image(bmc_img_name, bmc_img_size, bmc_capsule_img_name, bmc_pfm_img_name)
    bmc_image.set_hash_params(bmc_use_sha256_blocksign, bmc_use_sha384_blocksign)
    bmc_image.set_pfm_region(bmc_pfm_base, bmc_pfm_end)
    bmc_image.set_recovery_region(bmc_rec_base, bmc_rec_end)
    bmc_image.set_staging_region(bmc_stage_base, bmc_stage_end)
    bmc_image.set_csk_key_id_recovery(bmc_rec_csk_id)
    bmc_image.set_csk_key_id_pfm(bmc_pfm_csk_id)
    bmc_image.set_svn(bmc_svn)
    bmc_image.set_bkc(bmc_bkc)
    bmc_image.set_major_minor(bmc_major_rev, bmc_minor_rev)
    bmc_image.set_empty_to_full_ratio(bmc_empty_to_full_ratio)

    for i in range(len(bmc_fw_start_addrs)):
        bmc_image.add_fw_region(bmc_fw_start_addrs[i], bmc_fw_end_addrs[i])

    bmc_image.fill_all_fw_regions()
    bmc_image.create_pfm_spi_regions()

    # Setting bmc pfm configurations
    bmc_oem_spec_data_int_arr = [
        0x00, 0x1b, 0xbd, 0x59, 0xff, 0xff, 0xff, 0xff,
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
    ]
    bmc_oem_spec_data = bytearray(bmc_oem_spec_data_int_arr)
    bmc_image.pfm.set_oem_spec_data(bmc_oem_spec_data)

    """ Manually set the bmc pfm spi region configurations
    Note that spi_region[1], spi_region[6] and spi_region[7]
    are pfm, recover, and staging respectively"""
    bmc_image.pfm.spi_regions[0].set_region_protection_mask(0x1d)
    bmc_image.pfm.spi_regions[0].set_hash_info(True, False)

    bmc_image.pfm.spi_regions[1].set_region_protection_mask(0x0)
    bmc_image.pfm.spi_regions[1].set_hash_info(False, False)
    bmc_image.pfm.spi_regions[1].set_pfm_region(True)

    bmc_image.pfm.spi_regions[2].set_region_protection_mask(0x1f)
    bmc_image.pfm.spi_regions[2].set_hash_info(False, False)

    bmc_image.pfm.spi_regions[3].set_region_protection_mask(0x1f)
    bmc_image.pfm.spi_regions[3].set_hash_info(False, False)

    bmc_image.pfm.spi_regions[4].set_region_protection_mask(0x1f)
    bmc_image.pfm.spi_regions[4].set_hash_info(False, False)

    bmc_image.pfm.spi_regions[5].set_region_protection_mask(0x1d)
    bmc_image.pfm.spi_regions[5].set_hash_info(True, False)

    bmc_image.pfm.spi_regions[6].set_region_protection_mask(0x00)
    bmc_image.pfm.spi_regions[6].set_recovery_region(True)	
    bmc_image.pfm.spi_regions[6].set_hash_info(False, False)

    bmc_image.pfm.spi_regions[7].set_region_protection_mask(0x03)
    bmc_image.pfm.spi_regions[7].set_staging_region(True)
    bmc_image.pfm.spi_regions[7].set_hash_info(False, False)

    bmc_image.gen_all_fw_spi_hash()

    # Manually set the bmc pfm smbus rules regions
    bmc_image.pfm.create_smbus_rule()
    bmc_image.pfm.smbus_rules[0].set_bus_id(0x03)
    bmc_image.pfm.smbus_rules[0].set_rule_id(0x03)
    bmc_image.pfm.smbus_rules[0].set_dev_addr(0xd0)
    cmd_white_list = bytearray([0x1f, 0xfe, 0x89, 0x38, 0x2e, 0x00, 0xef, 0x3f]) + bytearray(24)
    bmc_image.pfm.smbus_rules[0].set_cmd_whitelist(cmd_white_list)

    bmc_image.pfm.create_smbus_rule()
    bmc_image.pfm.smbus_rules[1].set_bus_id(0x03)
    bmc_image.pfm.smbus_rules[1].set_rule_id(0x04)
    bmc_image.pfm.smbus_rules[1].set_dev_addr(0xd8)
    bmc_image.pfm.smbus_rules[1].set_cmd_whitelist(cmd_white_list)

    bmc_image.pfm.create_smbus_rule()
    bmc_image.pfm.smbus_rules[2].set_bus_id(0x01)
    bmc_image.pfm.smbus_rules[2].set_rule_id(0x06)
    bmc_image.pfm.smbus_rules[2].set_dev_addr(0xb0)
    cmd_white_list_int_arr = [
        0x68, 0x00, 0x00, 0x06, 0x00, 0x00, 0x01, 0xfc,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xfe,
        0xc6, 0xf3, 0xff, 0x05, 0xc0, 0x00, 0x00, 0x00,
        0x00, 0x00, 0xf9, 0x73, 0x00, 0x00, 0x00, 0x00
    ]
    cmd_white_list = bytearray(cmd_white_list_int_arr)
    bmc_image.pfm.smbus_rules[2].set_cmd_whitelist(cmd_white_list)

    bmc_image.pfm.create_smbus_rule()
    bmc_image.pfm.smbus_rules[3].set_bus_id(0x01)
    bmc_image.pfm.smbus_rules[3].set_rule_id(0x04)
    bmc_image.pfm.smbus_rules[3].set_dev_addr(0xb2)
    bmc_image.pfm.smbus_rules[3].set_cmd_whitelist(cmd_white_list)

    bmc_image.pfm.set_pfm_length(bmc_image.pfm.get_pfm_length())
    bmc_image.pfm.set_pc_type(3)
    bmc_image.pfm.set_csk_permissions(4)

    # Setting the Recovery Region Configurations
    bmc_image.recovery.set_full_img(bmc_img_name)
    bmc_image.recovery.set_pc_type(4)
    bmc_image.recovery.set_csk_permissions(8)
    bmc_image.recovery.gen_payload_and_bmps()

    bmc_image.create_all_images()

    ####################################### Create PCH Image ################################################

    pch_image = pfr_flash_image.pfr_flash_image(pch_img_name, pch_img_size, pch_capsule_img_name, pch_pfm_img_name)
    pch_image.set_hash_params(pch_use_sha256_blocksign, pch_use_sha384_blocksign)
    pch_image.set_pfm_region(pch_pfm_base, pch_pfm_end)
    pch_image.set_recovery_region(pch_rec_base, pch_rec_end)
    pch_image.set_staging_region(pch_stage_base, pch_stage_end)
    pch_image.set_csk_key_id_recovery(pch_rec_csk_id)
    pch_image.set_csk_key_id_pfm(pch_pfm_csk_id)
    pch_image.set_svn(pch_svn)
    pch_image.set_bkc(pch_bkc)
    pch_image.set_major_minor(pch_major_rev, pch_minor_rev)
    pch_image.set_empty_to_full_ratio(pch_empty_to_full_ratio)
    
    for i in range(len(pch_fw_start_addrs)):
        pch_image.add_fw_region(pch_fw_start_addrs[i], pch_fw_end_addrs[i])

    pch_image.fill_all_fw_regions()
    pch_image.create_pfm_spi_regions()

    # Setting pch pfm configurations
    pch_oem_spec_data = bytearray(16)
    pch_image.pfm.set_oem_spec_data(pch_oem_spec_data)

    """ Manually set the pch pfm spi region configurations
    Note that spi_region[8] contain pfm, recover, and staging. 
    Also note that the pch pfm has no smbus rules"""

    pch_image.pfm.spi_regions[0].set_region_protection_mask(0x1d)
    pch_image.pfm.spi_regions[0].set_hash_info(True, False)

    pch_image.pfm.spi_regions[1].set_region_protection_mask(0x1d)
    pch_image.pfm.spi_regions[1].set_hash_info(True, False)

    pch_image.pfm.spi_regions[2].set_region_protection_mask(0x1d)
    pch_image.pfm.spi_regions[2].set_hash_info(True, False)

    pch_image.pfm.spi_regions[3].set_region_protection_mask(0x1f)
    pch_image.pfm.spi_regions[3].set_hash_info(False, False)

    pch_image.pfm.spi_regions[4].set_region_protection_mask(0x1d)
    pch_image.pfm.spi_regions[4].set_hash_info(True, False)

    pch_image.pfm.spi_regions[5].set_region_protection_mask(0x1f)
    pch_image.pfm.spi_regions[5].set_hash_info(False, False)

    pch_image.pfm.spi_regions[6].set_region_protection_mask(0x1f)
    pch_image.pfm.spi_regions[6].set_hash_info(False, False)

    pch_image.pfm.spi_regions[7].set_region_protection_mask(0x1f)    
    pch_image.pfm.spi_regions[7].set_hash_info(False, False)

    pch_image.pfm.spi_regions[8].set_region_protection_mask(0x00)   
    pch_image.pfm.spi_regions[8].set_hash_info(False, False)
    pch_image.pfm.spi_regions[8].set_staging_region(True)
    pch_image.pfm.spi_regions[8].set_pfm_region(True)
    pch_image.pfm.spi_regions[8].set_recovery_region(True)

    pch_image.pfm.spi_regions[9].set_region_protection_mask(0x1d)   
    pch_image.pfm.spi_regions[9].set_hash_info(True, False)    

    pch_image.pfm.spi_regions[10].set_region_protection_mask(0x1f)    
    pch_image.pfm.spi_regions[10].set_hash_info(False, False)

    pch_image.gen_all_fw_spi_hash()

    pch_image.pfm.set_pfm_length(pch_image.pfm.get_pfm_length())
    pch_image.pfm.set_pc_type(1)
    pch_image.pfm.set_csk_permissions(3)

    # Setting the pch Recovery Region Configurations
    pch_image.recovery.set_full_img(pch_img_name)
    pch_image.recovery.set_pc_type(2)
    pch_image.recovery.set_csk_permissions(3)
    pch_image.recovery.gen_payload_and_bmps()

    pch_image.create_all_images()



if __name__ == "__main__":
    main()


