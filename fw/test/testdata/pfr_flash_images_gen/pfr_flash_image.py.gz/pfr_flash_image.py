import os
import hashlib
import math
import string 
import random
import xml.etree.ElementTree as ET

"""
Important Note: Need to use Python Version 3.6 or newer 

This is a library script containing functions/classes to generate
a full spi binary testing image along with its pfm and recovery capsules

Important Note: This script assumes we are in the ship/fw/test/testdata/pfr_flash_images directory

"""

class pfr_flash_image(object):
    page_size = 4096
    signature_size = 0x400

    # directories/commands/files for performing blocksigning with sha256 or sha384
    make_blk_sign_cmd_sha256 = "make -C ../../../../bin/blocksign_tool/source"
    make_blk_sign_cmd_sha384 = "make -C ../../../../bin/blocksign_secp384r1_fix/source"
    make_clean_blk_sign_cmd_sha256 = "make clean -C ../../../../bin/blocksign_tool/source"
    make_clean_blk_sign_cmd_sha384 = "make clean -C ../../../../bin/blocksign_secp384r1_fix/source"
    blk_sign_path_sha256 = "../../../../bin/blocksign_tool/source/blocksign -c ../../../../bin/blocksign_tool/config_xmls/"
    blk_sign_path_sha384 = "../../../../bin/blocksign_secp384r1_fix/source/blocksign -c ../../../../bin/blocksign_secp384r1_fix/config_xmls/"
    xml_sha256_path = "../../../../bin/blocksign_tool/config_xmls/"
    xml_sha384_path = "../../../../bin/blocksign_secp384r1_fix/config_xmls/"
    sha256_template_xml = "template_256.xml"
    sha384_template_xml = "template_384.xml"

    def __init__(self, image_name, image_size, rec_img_name, pfm_img_name):

        # construct default full image
        self.image_name = image_name        
        self.image_size = image_size
        self.image = open(self.image_name, "w+b")
        self.image.write(b'\xff' * self.image_size)
        self.rec_img_name = rec_img_name
        self.pfm_img_name = pfm_img_name

        #pfm and recover capsule objects
        self.pfm = pfm()
        self.recovery = rec_capsule()

        # pfm, recovery and staging addresses
        self.pfm_base = 0 
        self.pfm_end = 0
        self.rec_base = 0
        self.rec_end = 0
        self.stage_base = 0
        self.stage_end = 0  
    
        # empty to full ratio of the firmware regions
        self.empty_to_full_ratio = 0     
                	        		
        #fw start and end addr lists
        self.fw_start_addr_list = []	
        self.fw_end_addr_list = []
		
        #To choose which hashing algorithms to do code signing
        self.use_sha256 = True
        self.use_sha384 = False 

        self.full_img_sha256_fname = "hashsha256_" + self.image_name
        self.full_img_sha384_fname = "hashsha384_" + self.image_name

    # send in booleans to decide which hash(es) to use
    def set_hash_params(self, use_sha256, use_sha384):
        self.use_sha256 = use_sha256
        self.use_sha384 = use_sha384

    def set_pfm_region(self, pfm_base, pfm_end):
        self.pfm_base = pfm_base
        self.pfm_end = pfm_end
        self.recovery.set_pfm_region(pfm_base, pfm_end)
        
    def set_recovery_region(self, rec_base, rec_end):
        self.rec_base = rec_base
        self.rec_end = rec_end
        self.recovery.set_recovery_region(rec_base, rec_end)
        
    def set_staging_region(self, stage_base, stage_end):
        self.stage_base = stage_base
        self.stage_end = stage_end
        self.recovery.set_stage_region(stage_base, stage_end)

    def set_csk_key_id_recovery(self, value):
        self.recovery.set_csk_key_id(value)

    def set_csk_key_id_pfm(self, value):
        self.pfm.set_csk_key_id(value)

    def set_svn(self, value):
        self.pfm.set_svn(value)
    
    def set_bkc(self, value):
        self.pfm.set_bkc(value)

    def set_major_minor(self, major, minor):
        self.pfm.set_major_rev(major)
        self.pfm.set_minor_rev(minor)

    """set the empty to full ratio of firmware regions. Needs to be 
    within 0 and 1. Empty regions are pages written as 0xff"""
    def set_empty_to_full_ratio(self, value):
        self.empty_to_full_ratio = value

    def add_fw_region(self, start_addr, end_addr):
        self.fw_start_addr_list.append(start_addr)
        self.fw_end_addr_list.append(end_addr)		
	
    def fill_all_fw_regions(self):
        for i in range(len(self.fw_start_addr_list)):
            start_addr_in_pfr = self.in_pfm_staging_or_recovery(self.fw_start_addr_list[i])
            if not(start_addr_in_pfr):
                self.fill_fw_region(self.fw_start_addr_list[i], self.fw_end_addr_list[i])


    """ Fill the desired fw region within the binary image. 
    Some fraction of pages' bytes will be set with one random value ranging from 0 to 254.
    The rest will be all 0xff (empty) so that the image can be compressed. The percentage
    of empty data depends on empty_to_full ratio, which needs to be between
    0 and 1 """
    def fill_fw_region(self, start_addr, end_addr):
    
        fw_size = end_addr - start_addr
        num_pages = fw_size//self.page_size
        num_empty_pages_required = math.floor(self.empty_to_full_ratio*(num_pages))
        int_byte_data = 0
    
        set_all_ones = True
        num_empty_pages = 0
        num_pages_filled = 0
        self.image.seek(start_addr)
        for i in range (0, fw_size, self.page_size):        
            """randomize which pages will be empty,
            but make sure empty_to_full_ratio is met"""
            set_all_ones = ((random.randint(1,10)) <= 5)           
            num_pages_left = num_pages - num_pages_filled
            num_empty_to_fill = num_empty_pages_required - num_empty_pages			
            if ((num_pages_left) <= num_empty_to_fill):
                set_all_ones = True
            
            """don't let the first page be empty because
            the current unit tests erase the first page.
            this will need to be changed""" 			
            if (i == 0 or num_empty_to_fill == 0): 
                set_all_ones = False
            	        
            if (set_all_ones == True):
                byte_data = bytes([0xff])
                page_data = byte_data * self.page_size
                self.image.write(page_data)
                num_empty_pages += 1
                num_pages_filled += 1				
            else:
                int_byte_data = random.randint(0, 254)
                byte_data = bytes([int_byte_data])            
                page_data = byte_data * self.page_size
                self.image.write(page_data)            
                num_pages_filled += 1	                    		
        return

    def in_pfm_staging_or_recovery(self, addr):
        in_pfm_region = (addr >= self.pfm_base and addr < self.pfm_end) 
        in_recovery_region = (addr >= self.rec_base and addr < self.rec_end) 
        in_staging_region = (addr >= self.stage_base and addr < self.stage_end)
        return (in_pfm_region or in_recovery_region or in_staging_region)    

    """ after setting all the fw spi regions, staging, pfm and recovery,
    create the pfm spi_regions within the pfm object"""
    def create_pfm_spi_regions(self):
        spi_regions_start = self.fw_start_addr_list
        spi_regions_start.sort()
        spi_regions_end = self.fw_end_addr_list
        spi_regions_end.sort()
        for i in range(len(spi_regions_start)):
            self.pfm.create_spi_region(spi_regions_start[i], spi_regions_end[i])

    def gen_all_fw_spi_hash(self):
        for i in range(len(self.pfm.spi_regions)):
            if (self.pfm.spi_regions[i].has_sha256 == True):
                self.image.seek(self.pfm.spi_regions[i].fw_start_addr)			
                size = self.pfm.spi_regions[i].fw_end_addr - self.pfm.spi_regions[i].fw_start_addr
                data = self.image.read(size)
                self.pfm.spi_regions[i].sha256hash = gen_sha256_hash(data)

            if (self.pfm.spi_regions[i].has_sha384 == True):
                self.image.seek(self.pfm.spi_regions[i].fw_start_addr)			
                size = self.pfm.spi_regions[i].fw_end_addr - self.pfm.spi_regions[i].fw_start_addr
                data = self.image.read(size)
                self.pfm.spi_regions[i].sha384hash = gen_sha384_hash(data)

    """ use this to create full image and capsules once
    all configurations in the recovery and pfm objects are set"""	
    def create_all_images(self):

        if (self.use_sha256 and self.use_sha384):
            print("Both sha256 and sha384 code signing are set.")
            print("Will default to using only sha256. Cannot support both at the same time")

        # choose blocksigning parameters/files based on hash algo selection        
        if (self.use_sha256 == True):
            make_blk_sign_cmd = self.make_blk_sign_cmd_sha256
            blk_sign_path = self.blk_sign_path_sha256
            xml_path = self.xml_sha256_path
            template_xml_file = self.sha256_template_xml
            make_clean_cmd = self.make_clean_blk_sign_cmd_sha256
        elif (self.use_sha384 == True):
            make_blk_sign_cmd = self.make_blk_sign_cmd_sha384
            blk_sign_path = self.blk_sign_path_sha384
            xml_path = self.xml_sha384_path
            template_xml_file = self.sha384_template_xml
            make_clean_cmd = self.make_clean_blk_sign_cmd_sha384
        else:
            hash_set = (self.use_sha256 == True or self.use_sha384 == True)
            assert(hash_set == True), "choose which hash to use to perform code signing"

        # create the pfm image
        self.pfm.create_unsigned_pfm_img("tmp_pfm.bin")
        self.pfm.set_pfm_config_xml_file(xml_path, template_xml_file, "pfm.xml")
        self.pfm.block_sign_pfm("pfm.xml", "tmp_pfm.bin", self.pfm_img_name, make_blk_sign_cmd, make_clean_cmd, blk_sign_path)

        # copy pfm into full image
        pfm_img = open(self.pfm_img_name, "r+b")
        pfm_img.seek(0)
        pfm_data = pfm_img.read(os.path.getsize(self.pfm_img_name))
        self.image.seek(self.pfm_base)
        self.image.write(pfm_data)
        pfm_img.close()

        # create the recovery capsule
        self.recovery.set_pfm_img(self.pfm_img_name)
        self.recovery.create_unsigned_capsule("tmp_capsule.bin")
        self.recovery.set_capsule_config_xml_file(xml_path, template_xml_file, "rec.xml")
        self.recovery.blocksign_capsule("rec.xml", "tmp_capsule.bin", self.rec_img_name, make_blk_sign_cmd, make_clean_cmd, blk_sign_path)

        # copy recovery capsule into full image recovery region
        rec_img = open(self.rec_img_name, "r+b")
        rec_img.seek(0)
        rec_img_data = rec_img.read(os.path.getsize(self.rec_img_name))
        self.image.seek(self.rec_base)
        self.image.write(rec_img_data)
        rec_img.close()

    def create_full_img_sha256_hash(self):
        data = self.image.read(self.image_size)
        hash = gen_sha256_hash(data)
        hash_img = open(self.full_img_sha256_fname, "w+b")
        hash_img.write(hash)

    def create_full_img_sha384_hash(self):
        data = self.image.read(self.image_size)
        hash = gen_sha384_hash(data)
        hash_img = open(self.full_img_sha256_fname, "w+b")
        hash_img.write(hash)


class rec_capsule(object):
    tag_addr = 0
    version_addr = 0x4
    page_size_addr = 0x8
    pattern_size_addr = 0xc
    patt_compress_addr = 0x10
    bmp_num_bits_addr = 0x14
    payload_length_addr = 0x18
    reserved_addr = 0x1c
    reserved_size = 100
    active_bmp_addr = 0x80
    
    page_size_actual = 4096
    
    def __init__(self):
        
        # full image and pfm image info
        self.full_img = None
        self.pfm_img = None
        self.full_img_name = None
        self.pfm_img_name = None
        self.pfm_base = 0
        self.pfm_end = 0
        self.rec_base = 0
        self.rec_end = 0
        self.stage_base = 0
        self.stage_end = 0

        self.tag = 0x5f504243
        self.version = 0x00000002
        self.page_size_to_write = 4096
        self.pattern_size = 0x1
        self.patt_compress = 0x000000ff
        self.bmp_num_bits = 0
        self.payload_length = 0
        self.reserved = b'\x00' * self.reserved_size
        self.active_bmp = bytearray(0)
        self.compress_bmp = bytearray(0)
        self.payload = []

        # b0/b1 signature configurations
        self.pc_type = 0
        self.csk_permissions = 0
        self.csk_key_id = 0

    def set_full_img(self, full_img_name):
        self.full_img_name = full_img_name        	
        self.full_img = open(self.full_img_name, "r+b")
        self.bmp_num_bits = self.get_bmp_num_bits()

    def set_pfm_img(self, pfm_img_name):
        self.pfm_img_name = pfm_img_name
        self.pfm_img = open(self.pfm_img_name, "r+b")

    def set_pc_type(self, value):
        self.pc_type = value

    def set_csk_key_id(self, value):
        self.csk_key_id = value

    def set_csk_permissions(self, value):
        self.csk_permissions = value

    def set_pfm_region(self, base, end):
        self.pfm_base = base
        self.pfm_end = end

    def set_stage_region(self, base, end):
        self.stage_base = base
        self.stage_end = end

    def set_recovery_region(self, base, end):
        self.rec_base = base
        self.rec_end = end

    def in_pfm_staging_or_recovery(self, addr):
        in_pfm_region = (addr >= self.pfm_base and addr < self.pfm_end) 
        in_recovery_region = (addr >= self.rec_base and addr < self.rec_end) 
        in_staging_region = (addr >= self.stage_base and addr < self.stage_end)
        return (in_pfm_region or in_recovery_region or in_staging_region)

    def set_tag(self, tag):
        self.tag = tag

    def set_version(self, version):
        self.version = version

    def set_page_size_to_write(self, value):
        self.page_size_to_write = value

    def set_pattern_size(self, value):
        self.pattern_size = value

    def set_patt_for_compress(self, value):
        self.patt_compress = value

    def set_bmp_num_bits(self, value):
        self.bmp_num_bits = value

    def get_bmp_num_bits(self):
        full_img_size = os.path.getsize(self.full_img_name)
        return (full_img_size / self.page_size_actual)

    def set_payload_length(self, value):
        self.payload_length = value

    def get_payload_length(self):
        num_pgs_payload = len(self.payload)
        return (num_pgs_payload * self.page_size_actual)

    # given the full image, generate the payload and bitmaps
    def gen_payload_and_bmps(self):

        num_bmp_bits = self.get_bmp_num_bits()
        self.active_bmp = bytearray(int(num_bmp_bits/8))
        self.compress_bmp = bytearray(int(num_bmp_bits/8))
        page_patt = b'\xff' * self.page_size_actual	
        page = 0
        image_size = os.path.getsize(self.full_img_name)
        
        for img_addr in range (0, image_size, self.page_size_actual):
            if (not(self.in_pfm_staging_or_recovery(img_addr))):
                self.full_img.seek(int(img_addr))
                self.active_bmp[page >> 3] |= 1 << (7- (page % 8)) #Big Endian bit map
                page_data = self.full_img.read(self.page_size_actual)			
                if (page_data != page_patt):    		
                    self.compress_bmp[page >> 3] |= 1 << (7- (page % 8)) #Big Endian bit map
                    self.payload.append(page_data)				
        
            page += 1

        self.payload_length = self.get_payload_length()

    def create_unsigned_capsule(self, capsule_unsigned_name):
        
        num_bmp_bytes = self.get_bmp_num_bits()/8
        pfm_size = os.path.getsize(self.pfm_img_name)
        img = open(capsule_unsigned_name, "w+b")

        # Write signed pfm into recovery capsule
        self.pfm_img.seek(0)
        pfm_data = self.pfm_img.read(pfm_size)
        img.seek(0)
        img.write(pfm_data)

        # Write pbc info into recovery capsule        
        img.seek(pfm_size + self.tag_addr)
        img.write(self.tag.to_bytes(4, "little"))
        img.seek(pfm_size + self.version_addr)
        img.write(self.version.to_bytes(4, "little"))
        img.seek(pfm_size + self.page_size_addr)
        img.write(self.page_size_to_write.to_bytes(4, "little"))
        img.seek(pfm_size + self.pattern_size_addr)
        img.write(self.pattern_size.to_bytes(4, "little"))
        img.seek(pfm_size + self.patt_compress_addr)
        img.write(self.patt_compress.to_bytes(4, "little"))
        img.seek(pfm_size + self.bmp_num_bits_addr)
        img.write(int(self.bmp_num_bits).to_bytes(4, "little"))
        img.seek(pfm_size + self.payload_length_addr)
        img.write(self.payload_length.to_bytes(4, "little"))
        img.seek(pfm_size + self.reserved_addr)
        img.write(self.reserved)		
        img.seek(pfm_size + self.active_bmp_addr)
        img.write(bytes(self.active_bmp))
        img.seek(int(pfm_size + self.active_bmp_addr + num_bmp_bytes))
        img.write(bytes(self.compress_bmp))

        # Write the payload into the unsigned capsule
        img.seek(int(pfm_size + self.active_bmp_addr + 2*num_bmp_bytes))
        for i in range(len(self.payload)):
            img.write(bytes(self.payload[i]))

    def set_capsule_config_xml_file(self, xml_path, template_xml_file, new_xml_file):
        pc_type_tree = ["block0", "pctype"]
        pc_type_entry = str(self.pc_type)
        csk_permissions_tree = ["block1", "cskey", "permissions"]
        csk_permissions_entry = str(self.csk_permissions)
        csk_key_id_tree = ["block1", "cskey", "keyid"]
        csk_key_id_entry = str(self.csk_key_id)
        
        modify_xml_file(xml_path, template_xml_file, new_xml_file, pc_type_tree, pc_type_entry)
        modify_xml_file(xml_path, new_xml_file, new_xml_file, csk_permissions_tree, csk_permissions_entry)
        modify_xml_file(xml_path, new_xml_file, new_xml_file, csk_key_id_tree, csk_key_id_entry)

    # Use this to generate the signed capsule
    def blocksign_capsule(self, config_xml_file, unsigned_img_name, signed_img_name, make_blk_sign_cmd, make_clean_cmd, blk_sign_path):
        blocksign(config_xml_file, unsigned_img_name, signed_img_name, make_blk_sign_cmd, make_clean_cmd, blk_sign_path)

class pfm(object):

    tag_addr = 0
    svn_addr = 0x4
    bkc_addr = 0x5
    pfm_major_rev_addr = 0x6
    pfm_minor_rev_addr = 0x7
    reserved_addr = 0x8
    reserved_size = 4
    oem_spec_data_addr = 0xc
    oem_spec_data_size = 16
    length_addr = 0x1c
    pfm_body_addr = 0x20

    def __init__(self):        
        self.tag = 0x02b3ce1d
        self.svn = 0
        self.bkc = 0
        self.pfm_major_rev = 0
        self.pfm_minor_rev = 0
        self.oem_spec_data = bytearray(self.oem_spec_data_size)
        self.length = 0
        
        # b0/b1 signature configurations
        self.pc_type = 0
        self.csk_permissions = 0
        self.csk_key_id = 0

        # list of spi region objects
        self.spi_regions = []

        # list of smbus region objects
        self.smbus_rules = []

    def set_tag(self, tag):
        self.tag = tag

    def set_svn(self, svn):
        self.svn = svn

    def set_bkc(self, bkc):
        self.bkc = bkc

    def set_major_rev(self, maj_rev):
        self.pfm_major_rev = maj_rev

    def set_minor_rev(self, minor_rev):
        self.pfm_minor_rev = minor_rev

    # send in the data as a bytearray object
    def set_oem_spec_data(self, data):
        self.oem_spec_data = data

    def set_pfm_length(self, length):
        self.length = length

    def get_pfm_length(self):        
        smbus_rules_size = 0
        for i in range(len(self.smbus_rules)):
            smbus_rules_size += self.smbus_rules[i].size

        spi_regions_size = 0
        for i in range(len(self.spi_regions)):
            spi_regions_size += self.spi_regions[i].size

        length_without_pad = self.pfm_body_addr + spi_regions_size + smbus_rules_size
        byte_align_128_remain = length_without_pad % 128
        if (byte_align_128_remain != 0):
            length = (128 - byte_align_128_remain) + length_without_pad
        else:
            length = length_without_pad

        return length

    def create_spi_region(self, fw_start_addr, fw_end_addr):
        self.spi_regions.append(pfm_spi_region(fw_start_addr, fw_end_addr))

    def create_smbus_rule(self):
        self.smbus_rules.append(pfm_smbus_rule())

    def set_pc_type(self, value):
        self.pc_type = value

    def set_csk_key_id(self, value):
        self.csk_key_id = value

    def set_csk_permissions(self, value):
        self.csk_permissions = value

    def create_unsigned_pfm_img(self, pfm_unsigned_img_name):
        img = open(pfm_unsigned_img_name, "w+b")
        img.seek(self.tag_addr)
        img.write(self.tag.to_bytes(4, "little"))
        img.seek(self.svn_addr)
        img.write(bytes([self.svn]))
        img.seek(self.bkc_addr)
        img.write(bytes([self.bkc]))
        img.seek(self.pfm_major_rev_addr)
        img.write(bytes([self.pfm_major_rev]))
        img.seek(self.pfm_minor_rev_addr)
        img.write(bytes([self.pfm_minor_rev]))
        img.seek(self.reserved_addr)
        img.write(b'\xff' * self.reserved_size)
        img.seek(self.oem_spec_data_addr)
        img.write(bytes(self.oem_spec_data))
        img.seek(self.length_addr)
        img.write(self.length.to_bytes(4, "little"))

        # now write into spi and smbus rules.
        curr_addr = self.pfm_body_addr
        for i in range(len(self.spi_regions)):
            self.spi_regions[i].write_spi_region_into_image(img, curr_addr)
            curr_addr += self.spi_regions[i].size
        for i in range(len(self.smbus_rules)):
            self.smbus_rules[i].write_smbus_region_into_image(img, curr_addr)
            curr_addr += self.smbus_rules[i].size

        # Now make sure pfm has 128 byte alignment
        byte_128_align_remain = curr_addr % 128 
        if (byte_128_align_remain != 0):
            padding_size = 128 - byte_128_align_remain
            img.seek(curr_addr)
            img.write(b'\xff' * padding_size)

    def set_pfm_config_xml_file(self, xml_path, template_xml_file, new_xml_file):
        pc_type_tree = ["block0", "pctype"]
        pc_type_entry = str(self.pc_type)
        csk_permissions_tree = ["block1", "cskey", "permissions"]
        csk_permissions_entry = str(self.csk_permissions)
        csk_key_id_tree = ["block1", "cskey", "keyid"]
        csk_key_id_entry = str(self.csk_key_id)
        
        modify_xml_file(xml_path, template_xml_file, new_xml_file, pc_type_tree, pc_type_entry)
        modify_xml_file(xml_path, new_xml_file, new_xml_file, csk_permissions_tree, csk_permissions_entry)
        modify_xml_file(xml_path, new_xml_file, new_xml_file, csk_key_id_tree, csk_key_id_entry)

    # use this to generate the signed pfm file 
    def block_sign_pfm(self, config_xml_file, unsigned_img_name, signed_img_name, make_blk_sign_cmd, make_clean_cmd, blk_sign_path):
        blocksign(config_xml_file, unsigned_img_name, signed_img_name, make_blk_sign_cmd, make_clean_cmd, blk_sign_path)

class pfm_spi_region(object):

    pfm_def_type_addr = 0x0
    pfm_def_type = 0x1	
    protection_mask_addr = 0x1
    hash_info_addr = 0x2
    reserved_addr = 0x4
    reserved_size = 4
    fw_start_addr_addr = 0x8
    fw_end_addr_addr = 0x0c
    hash_adr_base = 0x10	

    def __init__(self, fw_start_addr, fw_end_addr):
        self.protection_mask = 0
        self.has_sha256 = False
        self.has_sha384 = False
        self.sha256hash = b'\xff' * 32
        self.sha384hash = b'\xff' * 48		
        self.pfm_hash_info = 0 		
        self.fw_start_addr = fw_start_addr
        self.fw_end_addr = fw_end_addr
        self.size = 0
        self.in_stage = False
        self.in_pfm = False		
        self.in_recov = False
		
    def set_region_protection_mask(self, value):
        self.protection_mask = value

    def set_hash_info(self, has_sha256, has_sha384):
        self.has_sha256 = has_sha256
        self.has_sha384 = has_sha384

        if (self.has_sha256 == True):
            sha_256_mask = 0x1
        else:
            sha_256_mask = 0		
        if (self.has_sha384 == True):
            sha_384_mask = 0x2
        else:
            sha_384_mask = 0

        self.pfm_hash_info = sha_256_mask | sha_384_mask
        
        # since hash info given, can now know size of region
        self.set_size()

    def set_sha256_hash(self, hash):
        self.sha256hash = hash

    def set_sha384_hash(self, hash):
        self.sha384hash = hash

    def set_staging_region(self, is_staging):
        self.in_stage = is_staging	
	
    def set_recovery_region(self, is_recov):
        self.in_recov = is_recov
	
    def set_pfm_region(self, is_pfm):
	    self.in_pfm = is_pfm

    def set_size(self):
        if ((self.has_sha256 == True) and (self.has_sha384 == True)):
            self.size = 96
        elif (self.has_sha256 == True):
            self.size = 48            
        elif (self.has_sha384 == True):
            self.size = 64
        else:
            self.size = 16
	
    """ Use this to write PFM SPI region into the image 
    within the pfm body once all configurations are set """	
    def write_spi_region_into_image(self, image, base_addr):
        image.seek(base_addr + self.pfm_def_type_addr)                        	
        image.write(bytes([self.pfm_def_type]))
        image.seek(base_addr + self.protection_mask_addr)
        image.write(bytes([self.protection_mask]))
        image.seek(base_addr + self.hash_info_addr)
        image.write(bytes([self.pfm_hash_info]))
        image.seek(base_addr + self.reserved_addr)
        image.write(b'\xff' * self.reserved_size)
        image.seek(base_addr + self.fw_start_addr_addr)
        image.write(self.fw_start_addr.to_bytes(4, "little"))
        image.seek(base_addr + self.fw_end_addr_addr)		
        image.write(self.fw_end_addr.to_bytes(4, "little"))

        image.seek(base_addr + self.hash_adr_base)
        if (self.has_sha256 == True and self.has_sha384 == True):
            image.write(self.sha256hash)
            image.write(self.sha384hash)
        elif (self.has_sha256 == True):
            image.write(self.sha256hash)
        elif (self.has_sha384 == True):
            image.write(self.sha384hash)
        else:
            return		

class pfm_smbus_rule(object):
    pfm_def_type_addr = 0
    reserved_addr = 1
    reserved_size = 4
    pfm_def_type = 0x2
    bus_id_addr = 0x05
    rule_id_addr = 0x06
    dev_addr_addr = 0x07
    cmd_whitelist_addr = 0x8
    cmd_whitelist_size = 32
    size = 40

    def __init__(self):
        self.bus_id = 0
        self.rule_id = 0
        self.dev_addr = 0
        self.cmd_whitelist = bytearray(self.cmd_whitelist_size)
		
    def set_bus_id(self, bus_id):
        self.bus_id = bus_id	

    def set_rule_id(self, rule_id):
        self.rule_id = rule_id	

    def set_dev_addr(self, dev_addr):
        self.dev_addr = dev_addr	

    """ send in bytearray object of size 32 to 
    set command whitelist """
    def set_cmd_whitelist(self, whitelist_arr):
        self.cmd_whitelist = whitelist_arr

    """ Use this to write PFM SMBUS region into the image 
    within the pfm body once all configurations are set """
    def write_smbus_region_into_image(self, image, base_adr):
        image.seek(base_adr + self.pfm_def_type_addr)
        image.write(bytes([self.pfm_def_type]))
        image.seek(base_adr + self.reserved_addr)
        image.write(b'\xff' * self.reserved_size)
        image.seek(base_adr + self.bus_id_addr)
        image.write(bytes([self.bus_id]))
        image.seek(base_adr + self.rule_id_addr)
        image.write(bytes([self.rule_id]))
        image.seek(base_adr + self.dev_addr_addr)
        image.write(bytes([self.dev_addr]))
        image.seek(base_adr + self.cmd_whitelist_addr)
        image.write(bytes(self.cmd_whitelist))

# generates sha384 hash from binary image data
def gen_sha384_hash(data):
    hash = hashlib.sha384()
    hash.update(data)
    return (hash.digest())

# generates sha256 hash from binary image data
def gen_sha256_hash(data):
    hash = hashlib.sha256()
    hash.update(data)
    return (hash.digest())

def blocksign(config_xml_file, unsigned_img_name, signed_img_name, make_blk_sign_cmd, make_clean_cmd, blk_sign_path):
    
    # perform blocksign and copy into signature region
    os.system(make_clean_cmd)
    os.system(make_blk_sign_cmd)
    block_sign_cmd = blk_sign_path + config_xml_file + " -o " + signed_img_name + " " + unsigned_img_name
    os.system(block_sign_cmd)

"""
Given a template xml file, will make a modification and generate a new xml file.
Send in field_edit_tree as an array which contains a hierarchy of nodes. The 
final element within the array is the element to edit.
i.e set field_edit_tree = ["block 0", "pctype"] to edit pctype
Note that field_edit_tree array and value both need to contain strings 
"""
def modify_xml_file(xml_path, template_xml_file, new_xml_file, field_edit_tree, value):

    temp_xml_file = xml_path + template_xml_file
    tree = ET.parse(temp_xml_file)
    root = tree.getroot()

    cur_node = root 
    for i in range(len(field_edit_tree)):
        for child in cur_node:
            if (str(child.tag) == field_edit_tree[i]):
                cur_node = child
                break

    cur_node.text = value
    final_xml_file = xml_path + new_xml_file
    tree.write(final_xml_file, "UTF-8")
